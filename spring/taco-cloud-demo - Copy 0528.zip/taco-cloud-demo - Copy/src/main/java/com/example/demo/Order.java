package com.example.demo;

import lombok.Data;
import org.hibernate.validator.constraints.CreditCardNumber;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Data
public class Order {
    private long id;
    private Date placedAt;

    @NotBlank(message = "订单名称必填")
    private String name;

    @NotBlank(message = "街道必填")
    private String street;

    @NotBlank(message = "城市必填")
    private String city;

    @NotBlank(message = "省必填")
    private String state;

    @NotBlank(message = "邮编必填")
    private String zip;

    @CreditCardNumber(message = "不是信用卡号")
    private String ccNumber;

    @Pattern(regexp = "^(0[1-9]|1[0-2])([\\/][1-9][0-9])$",
    message = "按MM/YY填写")
    private String ccExpiration;

    @Digits(integer = 3, fraction = 0, message = "验证码有误")
    private String ccCVV;

    private List<Taco> tacos = new ArrayList<>();

    public void addDesign(Taco design) {
        this.tacos.add(design);
    }


}
