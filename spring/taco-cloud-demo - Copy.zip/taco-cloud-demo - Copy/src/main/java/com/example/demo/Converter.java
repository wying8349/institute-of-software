package com.example.demo;

import com.example.demo.Ingredient;

public interface Converter<T, T1> {
    public Ingredient convert(String id);
}
