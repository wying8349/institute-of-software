package com.example.demo.data;

import com.example.demo.Order;

public interface OrderRepository {
    Order save(Order order);
}
