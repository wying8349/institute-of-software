package com.example.demo.data;

import com.example.demo.Taco;

public interface TacoRepository {
    Taco save (Taco design);
}
